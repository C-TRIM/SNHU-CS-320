# CS 320 Project One (Contact/Task/Appointment Services)

## How to run tests and coverage
```bash
mvn -q -e -DskipTests=false test
# Coverage report:
# target/site/jacoco/index.html
```
This project uses:
- JUnit 5 (jupiter)
- JaCoCo for coverage (should exceed 80% with these tests)
